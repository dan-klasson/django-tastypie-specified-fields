from distutils.core import setup
setup(name='django-tastypie-specified-fields',
      version='0.1',
      py_modules=['specifiedfields'],
      )
